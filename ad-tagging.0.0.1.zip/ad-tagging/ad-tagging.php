<?php
/**
 * Plugin Name: Ad Tagging
 * Plugin URI: 
 * Description: A plugin to add tag to affiliate posts.
 * Version: 0.0.1
 * Requires at least: 5.0
 * Requires PHP: 7.0
 * Author: shinya-blogger
 * Author URI: https://note.com/shinya_blogger/
 * License: GPL2
 */
/*  Copyright 2023 shinya-blogger (email: shinya.blogger@gmail.com)
 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
     published by the Free Software Foundation.
 
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

add_action('plugins_loaded', 'syb_ad_tagging_init');

function syb_ad_tagging_init() {
    if (is_admin()) {
        load_plugin_textdomain('ad-tagging', false, dirname(plugin_basename( __FILE__ )) . '/languages/');
    }
}

add_action('admin_menu', 'syb_ad_tagging_menu');

function syb_ad_tagging_menu() {
    $page_title = 'Ad Tagging';
    $menu_title = 'Ad Tagging';
    $capability = 'manage_options';
    $menu_slug = 'syb_ad_tagging';
    add_management_page($page_title, $menu_title, $capability, $menu_slug, 'syb_ad_tagging_admin_page');

    $page_title = 'Ad Tagging 設定';
    $menu_title = 'Ad Tagging 設定';
    add_options_page($page_title, $menu_title, $capability, $menu_slug, 'syb_ad_tagging_option_page');
}

function syb_ad_tagging_admin_page() {
    require_once __DIR__ . '/includes/page/Tool.php';
    $page = new SybAdTagging\Page\Tool();
    $page->show();
}
function syb_ad_tagging_option_page() {
    require_once __DIR__ . '/includes/page/Option.php';
    $page = new SybAdTagging\Page\Option();
    $page->show();
}

add_action('rest_api_init', 'syb_ad_tagging_register_rest');

function syb_ad_tagging_register_rest() {
    require_once __DIR__ . '/includes/api/Api.php';

    SybAdTagging\Api\Api::init();

    remove_action( 'rest_api_init', 'syb_ad_tagging_register_reset' );
}


add_filter('plugin_action_links', 'syb_ad_tagging_add_settings_link', 10, 2);

function syb_ad_tagging_add_settings_link($links, $file) {

	if ($file === plugin_basename(__FILE__)) {

		$settings_url = add_query_arg(
			[
				'page' => 'syb_ad_tagging',
            ],
			admin_url('options-general.php')
		);

		$settings_link = '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings') . '</a>';
		array_unshift($links, $settings_link);
	}

	return $links;
}

register_uninstall_hook(__FILE__, 'syb_ad_tagging_uninstall');

function syb_ad_tagging_uninstall() {
    require_once __DIR__ . '/includes/model/Settings.php';
    $settings = new SybAdTagging\Model\Settings();
    $settings->delete();

}

?>
