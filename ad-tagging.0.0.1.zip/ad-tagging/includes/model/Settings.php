<?php

namespace SybAdTagging\Model;

/**
 * Ad Tagging plugin settings using Options API
 */
class Settings {

    private $adTagName = null;
    private $affiliateUrlList = [];

	public function __construct() {
        $defaultAffiliateUrls = json_encode([
            'https://amzn.to/',
            'https://www.amazon.co.jp/',
            'https://hb.afl.rakuten.co.jp/',
            'https://px.a8.net/',
            'https://ck.jp.ap.valuecommerce.com/',
            'https://h.accesstrade.net/',
            'https://t.afi-b.com/',
            'https://www.rentracks.jp/adx/',
            'https://click.linksynergy.com/',
            'https://smart-c.jp/c?',
            'https://c2.cir.io/',
            'https://click.j-a-net.jp/',
            'https://www.tcs-asp.net/alink',
            'https://www.infotop.jp/click.php',
            'https://ad2.trafficgate.net/',
        ]);

        $this->adTagName = get_option('syb_ad_tagging.ad_tag_name', 'AD');
        $affiliateUrls = get_option('syb_ad_tagging.affiliate_urls', $defaultAffiliateUrls);
        $this->affiliateUrlList = json_decode($affiliateUrls);
	}

    public function getAdTagName() {
        return $this->adTagName;
    }

    public function getAffiliateUrlList() {
        return $this->affiliateUrlList;
    }

    public function setAdTagName($adTagName) {
        $this->adTagName = $adTagName;
    }

    public function setAffiliateUrlList($affiliateUrlList) {
        $this->affiliateUrlList = $affiliateUrlList;
    }

    public function store() {
        if (get_option('syb_ad_tagging.ad_tag_name') === false) {
			add_option('syb_ad_tagging.ad_tag_name', $this->adTagName);
		} else {
			update_option('syb_ad_tagging.ad_tag_name', $this->adTagName);
		}

		if (get_option('syb_ad_tagging.affiliate_urls') === false) {
			add_option('syb_ad_tagging.affiliate_urls', json_encode($this->affiliateUrlList));
		} else {
			update_option('syb_ad_tagging.affiliate_urls', json_encode($this->affiliateUrlList));
		}
    }

    public function delete() {
        delete_option('syb_ad_tagging.ad_tag_name');
        delete_option('syb_ad_tagging.affiliate_urls');
    }
   
}
