<?php

namespace SybAdTagging\Page;


class Tool {

	public function __construct() {
		global $wpdb;

		$wpdb->hide_errors();
	}

    public function show() {
        $context = json_encode([
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
        ]);

        require_once __DIR__ . '/../view/tool.php';
    }
   
}
