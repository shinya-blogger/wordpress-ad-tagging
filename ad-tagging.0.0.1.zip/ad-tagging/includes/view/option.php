<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
<script src="https://unpkg.com/axios@1.1.2/dist/axios.min.js"></script>

<div id="app">
    <div class="wrap">
        <h1>Ad Tagging設定</h1>

        <div v-if="message != null" class="notice notice-success is-dismissible">
            <p>{{ message }}</p>
        </div>

        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="ad_tag_name">タグ</label></th>
                    <td>
                        <select v-model="adTagName">
                            <option>AD</option>
                            <option>PR</option>
                            <option>Sponsored</option>
                            <option>アフィリエイト広告</option>
                            <option>プロモーション</option>
                            <option>広告</option>
                            <option>宣伝</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="affiliate_urls">アフィリエイトURL</label></th>
                    <td>
                        <textarea 
                            v-model="affiliateUrls" 
                            rows="10" class="large-text" placeholder="https:// から始まるURL">
                        </textarea>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="変更を保存" 
                :disabled="!validateForm()"
                @click="updateSettings">
        </p>
    </div>
</div>


<script>
    const context = <?= $context ?>;
    const nonce = context.nonce;
    axios.defaults.headers.common['X-WP-Nonce'] = nonce;
    const { createApp, ref } = Vue;

    createApp({
        setup() {
            const message = ref(null);
            const adTagName = ref(context.adTagName);
            const affiliateUrls = ref(context.affiliateUrlList.join('\r\n'));

            function validateForm() {
                if (affiliateUrls.value.trim() == '') {
                    return false;
                }
                return true;
            }

            function updateSettings(event) {
                message.value = null;
                axios.post("/wp-json/syb-ad-tagging/update-settings", {
                    'ad_tag_name': adTagName.value,
                    'affiliate_urls': affiliateUrls.value
                    })
                    .then((response) => {
                        message.value = `設定を更新しました。`;
                    })
                    .catch((reason) => {alert(reason);})
                    .finally(() => {});
            }

            return {
                message,
                adTagName,
                affiliateUrls,
                validateForm,
                updateSettings,
            }
        }
    }).mount('#app');

</script>