<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
<script src="https://unpkg.com/axios@1.1.2/dist/axios.min.js"></script>

<div id="app">
    <div class="wrap">
        <h1>Ad Tagging</h1>

        <p>タグ名やアフィリエイトURLは <a :href="adminUrl + 'options-general.php?page=syb_ad_tagging'">Ad Tagging 設定</a> で変更できます。</p>

        <div v-if="message != null" class="notice notice-success is-dismissible">
            <p>{{ message }}</p>
        </div>

        <p>
            <input type="button" 
                class="button"
                :class="{ 'button-primary': posts == null || posts.length == 0 }"
                value="アフィリエイト記事を検索"
                :disabled="processingSearch"
                :style="{cursor: processingSearch ? 'progress': ''}"
                @click="searchPosts">
            &nbsp;
            <input type="button" class="button button-primary" 
                value="チェックした記事のタグを更新"
                v-show="posts && posts.length > 0"
                :disabled="checkedPosts.length == 0 || processingUpdate"
                :style="{cursor: processingUpdate ? 'progress': ''}"
                @click="updateTag">
        </p>

        <div v-if="posts != null">
            <p>記事数：{{ posts.length }}</p>

            <table class="wp-list-table widefat fixed striped table-view-list posts">
                <thead>
                    <tr>
                        <th class="check-column"></th>
                        <th style="width: 3em">ID</th>
                        <th>タイトル</th>
                        <th>タグ(変更前)</th>
                        <th>タグ(変更後)</th>
                    </tr>
                </thead>
                <tr v-for="post in posts">
                    <th class="check-column">
                        <input type="checkbox" 
                            :value="post.id" 
                            v-model="checkedPosts"
                            :disabled="!(post.editable && post.tag_required)" />
                    </th>
                    <td>{{ post.id }}</td>
                    <td><a :href="post.link">{{ post.title.rendered }}</a></td>
                    <td>{{ post.tags.join('、') }}</td>
                    <td>{{ post.new_tags.join('、') }}</td>
                </tr>
            </table>

            <p>記事数：{{ posts.length }}</p>

        </div>
    </div>
</div>


<script>
    const context = <?= $context ?>;
    const nonce = context.nonce;
    axios.defaults.headers.common['X-WP-Nonce'] = nonce;
    const { createApp, ref } = Vue;

    createApp({
        setup() {
            const adminUrl = ref(context.adminUrl);
            const message = ref(null);
            const posts = ref(null);
            const checkedPosts = ref([]);
            const processingSearch = ref(false);
            const processingUpdate = ref(false);

            function searchPosts() {
                message.value = null;
                processingSearch.value = true;
                checkedPosts.value = [];
                axios.get("/wp-json/syb-ad-tagging/search-posts")
                    .then((response) => {
                        posts.value = response.data;
                        response.data.forEach((post) => {
                            if (post.editable && post.tag_required) {
                                checkedPosts.value.push(post.id);
                            }
                        });
                    })
                    .catch((reason) => {alert(reason);})
                    .finally(() => {processingSearch.value = false;});

            }

            function updateTag(event) {
                message.value = null;
                processingUpdate.value = true;
                axios.post("/wp-json/syb-ad-tagging/update-post-tags", {id: checkedPosts.value})
                    .then((response) => {
                        message.value = `${checkedPosts.value.length}件の記事のタグを更新しました。`;
                        posts.value = null;
                    })
                    .catch((reason) => {alert(reason);})
                    .finally(() => {processingUpdate.value = false;});
            }
    
            return {
                adminUrl,
                message,
                posts,
                checkedPosts,
                processingSearch,
                processingUpdate,
                searchPosts,
                updateTag,
            }
        }
    }).mount('#app');

</script>