<?php

namespace SybAdTagging\Page;

abstract class BasePage {

    abstract public function show();
}
