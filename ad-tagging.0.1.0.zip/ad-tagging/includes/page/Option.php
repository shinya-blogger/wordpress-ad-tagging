<?php

namespace SybAdTagging\Page;

use SybAdTagging\Model\Settings;

require_once __DIR__ . '/BasePage.php';
require_once __DIR__ . '/../model/Settings.php';

class Option extends BasePage {

	public function __construct() {
		global $wpdb;

		$wpdb->hide_errors();
	}

    public function show() {
		$settings = new Settings();

        $context = json_encode([
            'nonce' => wp_create_nonce('wp_rest'),
            'adTagName' => $settings->getAdTagName(),
            'affiliateUrlList' => $settings->getAffiliateUrlList(),
            'updateOnSave' => $settings->getUpdateOnSave(),
        ]);

        require_once __DIR__ . '/../view/option.php';
    }

    public function getUrl() {
        $url = add_query_arg(
			[
				'page' => 'syb_ad_tagging',
            ],
			admin_url('options-general.php')
		);
        return $url;
    }
   
}
