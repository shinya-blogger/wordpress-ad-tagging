<?php

namespace SybAdTagging\Page;

require_once __DIR__ . '/BasePage.php';

class Tool extends BasePage {

	public function __construct() {
		global $wpdb;

		$wpdb->hide_errors();
	}

    public function show() {
        $context = json_encode([
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
        ]);

        require_once __DIR__ . '/../view/tool.php';
    }
   
}
