<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
<script src="https://unpkg.com/axios@1.1.2/dist/axios.min.js"></script>

<div id="app">
    <div class="wrap">
        <h1><?php esc_html_e('Ad Tagging', 'syb-ad-tagging'); ?></h1>

        <p>
            <?php 
                printf(
                    __(
                        'Tag names and affiliate URLs can be changed in the <a :href="%1$s">Ad Tagging settings</a>.',
                        'syb-ad-tagging'
                    ),
                    "adminUrl + 'options-general.php?page=syb_ad_tagging'"
                );
            ?>
        </p>

        <div v-if="message != null" class="notice notice-success is-dismissible">
            <p>{{ message }}</p>
        </div>

        <p>
            <input type="button" 
                class="button"
                :class="{ 'button-primary': posts == null || posts.length == 0 }"
                value="<?php esc_html_e('Search for affiliate posts', 'syb-ad-tagging'); ?>"
                :disabled="processingSearch"
                :style="{cursor: processingSearch ? 'progress': ''}"
                @click="searchPosts">
            &nbsp;
            <input type="button" class="button button-primary" 
                value="<?php esc_html_e('Update tags on checked posts', 'syb-ad-tagging'); ?>"
                v-show="posts && posts.length > 0"
                :disabled="checkedPosts.length == 0 || processingUpdate"
                :style="{cursor: processingUpdate ? 'progress': ''}"
                @click="updateTag">
        </p>

        <div v-if="posts != null">
            <p><?php esc_html_e('Number of posts:', 'syb-ad-tagging'); ?> {{ posts.length }}</p>

            <table class="wp-list-table widefat fixed striped table-view-list posts">
                <thead>
                    <tr>
                        <th class="check-column"></th>
                        <th style="width: 3em">ID</th>
                        <th><?php esc_html_e('Title'); ?></th>
                        <th><?php esc_html_e('Tags before change', 'syb-ad-tagging'); ?></th>
                        <th><?php esc_html_e('Tags after change', 'syb-ad-tagging'); ?></th>
                    </tr>
                </thead>
                <tr v-for="post in posts">
                    <th class="check-column">
                        <input type="checkbox" 
                            :value="post.id" 
                            v-model="checkedPosts"
                            :disabled="!(post.editable && post.tag_required)" />
                    </th>
                    <td>{{ post.id }}</td>
                    <td><a :href="post.link">{{ post.title.rendered }}</a></td>
                    <td>{{ post.tags.join('、') }}</td>
                    <td>{{ post.new_tags.join('、') }}</td>
                </tr>
            </table>

            <p><?php esc_html_e('Number of posts:', 'syb-ad-tagging'); ?> {{ posts.length }}</p>

        </div>
    </div>
</div>


<script>
    const context = <?= $context ?>;
    const nonce = context.nonce;
    axios.defaults.headers.common['X-WP-Nonce'] = nonce;
    const { createApp, ref } = Vue;

    createApp({
        setup() {
            const adminUrl = ref(context.adminUrl);
            const message = ref(null);
            const posts = ref(null);
            const checkedPosts = ref([]);
            const processingSearch = ref(false);
            const processingUpdate = ref(false);

            function searchPosts() {
                message.value = null;
                processingSearch.value = true;
                checkedPosts.value = [];
                axios.get("/wp-json/syb-ad-tagging/search-posts")
                    .then((response) => {
                        posts.value = response.data;
                        response.data.forEach((post) => {
                            if (post.editable && post.tag_required) {
                                checkedPosts.value.push(post.id);
                            }
                        });
                    })
                    .catch((reason) => {alert(reason);})
                    .finally(() => {processingSearch.value = false;});

            }

            function updateTag(event) {
                message.value = null;
                processingUpdate.value = true;
                axios.post("/wp-json/syb-ad-tagging/update-post-tags", {id: checkedPosts.value})
                    .then((response) => {
                        if (checkedPosts.value.length == 1) {
                            message.value = `<?php _e('Updated tags for 1 post.', 'syb-ad-tagging'); ?>`;
                        } else {
                            message.value = `<?php printf(__('Updated tags for %s posts.', 'syb-ad-tagging'), 0); ?>`.replace('0', checkedPosts.value.length);
                        }
                        posts.value = null;
                    })
                    .catch((reason) => {alert(reason);})
                    .finally(() => {processingUpdate.value = false;});
            }
    
            return {
                adminUrl,
                message,
                posts,
                checkedPosts,
                processingSearch,
                processingUpdate,
                searchPosts,
                updateTag,
            }
        }
    }).mount('#app');

</script>