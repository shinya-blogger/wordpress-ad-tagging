<?php

namespace SybAdTagging\Page;

require_once __DIR__ . '/BasePage.php';

class Tool extends BasePage {

	public function __construct() {
		global $wpdb;

		$wpdb->hide_errors();
	}

    public function show() {
        wp_enqueue_script('vue-global', 'https://unpkg.com/vue@3/dist/vue.global.js', array(), null, array());
        wp_enqueue_script('axios', 'https://unpkg.com/axios@1.1.2/dist/axios.min.js', array(), null, array());

        $context = json_encode([
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
        ]);

        require_once __DIR__ . '/../view/tool.php';
    }
   
}
